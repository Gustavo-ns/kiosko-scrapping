<?php
header('Content-Type: application/json');

// Cargar configuración de la base de datos
$cfg = require 'config.php';

try {
    // Conexión a la base de datos
    $pdo = new PDO(
        "mysql:host={$cfg['db']['host']};dbname={$cfg['db']['name']};charset={$cfg['db']['charset']}",
        $cfg['db']['user'],
        $cfg['db']['pass'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

    // URL de la API y API key
    $apiUrl = "https://api.meltwater.com/v3/exports/recurring";
    $apiKey = "8PMcUPYZ1M954yDpIh6mI8CE61fqwG2LFulSbPGo";

    // Inicializar cURL
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "apikey: $apiKey"
    ]);

    // Ejecutar la solicitud
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        throw new Exception("Error de cURL: " . curl_error($ch));
    }

    curl_close($ch);

    // Decodificar JSON inicial
    $data = json_decode($response, true);
    if (!isset($data['recurring_exports'][0]['data_url'])) {
        throw new Exception("No se encontró 'data_url'.");
    }

    // Obtener la URL de los datos
    $dataUrl = $data['recurring_exports'][0]['data_url'];
    
    // Obtener los datos del JSON
    $response = file_get_contents($dataUrl);
    if ($response === FALSE) {
        throw new Exception("Error al obtener los datos del archivo JSON.");
    }

    $data = json_decode($response, true);
    if (!isset($data['documents'])) {
        throw new Exception("No se encontraron documentos en la respuesta.");
    }

    // Preparar la consulta de inserción
    $stmt = $pdo->prepare("INSERT INTO pk_melwater (
        external_id, published_date, source_id, social_network, 
        country_code, country_name, author_name, content_image, 
        content_text, url_destino, input_names
    ) VALUES (
        :external_id, :published_date, :source_id, :social_network,
        :country_code, :country_name, :author_name, :content_image,
        :content_text, :url_destino, :input_names
    ) ON DUPLICATE KEY UPDATE
        published_date = VALUES(published_date),
        source_id = VALUES(source_id),
        social_network = VALUES(social_network),
        country_code = VALUES(country_code),
        country_name = VALUES(country_name),
        author_name = VALUES(author_name),
        content_image = VALUES(content_image),
        content_text = VALUES(content_text),
        url_destino = VALUES(url_destino),
        input_names = VALUES(input_names)");

    $country_names = [
        'ar' => 'Argentina',
        'bo' => 'Bolivia',
        'br' => 'Brasil',
        'cl' => 'Chile',
        'co' => 'Colombia',
        'ec' => 'Ecuador',
        'us' => 'Estados Unidos',
        'mx' => 'México',
        'pa' => 'Panamá',
        'py' => 'Paraguay',
        'pe' => 'Perú',
        'do' => 'República Dominicana',
        'uy' => 'Uruguay',
        've' => 'Venezuela',
        'es' => 'España',
        'gb' => 'Reino Unido',
        'zz' => 'Desconocido'
    ];

    $updatedCount = 0;
    foreach ($data['documents'] as $doc) {
        $author_name = isset($doc['author']['name']) ? $doc['author']['name'] : 'N/A';
        $content_image = isset($doc['content']['image']) ? $doc['content']['image'] : null;
        $content_text = isset($doc['content']['opening_text']) ? $doc['content']['opening_text'] : '';
        $country_code = strtolower(isset($doc['location']['country_code']) ? $doc['location']['country_code'] : 'zz');
        $country_name = isset($country_names[$country_code]) ? $country_names[$country_code] : ucfirst($country_code);
        $url_destino = isset($doc['url']) ? $doc['url'] : '#';
        $external_id = isset($doc['author']['external_id']) ? $doc['author']['external_id'] : '';
        $published_date = isset($doc['published_date']) ? $doc['published_date'] : '';
        $source_id = isset($doc['source']['id']) ? $doc['source']['id'] : '';
        
        // Debug para el ID específico
        if ($external_id === '8105922') {
            error_log("Datos para ID 8105922:");
            error_log("Content Image: " . print_r($content_image, true));
            error_log("Raw document data: " . print_r($doc, true));
        }
        
        // Extraer red social del source_id
        $social_network = '';
        if (!empty($source_id) && strpos($source_id, 'social:') === 0) {
            $parts = explode(':', $source_id);
            $social_network = isset($parts[1]) ? ucfirst($parts[1]) : '';
        }

        // Obtener los inputs names
        $input_names = [];
        if (isset($doc['matched']['inputs']) && is_array($doc['matched']['inputs'])) {
            foreach ($doc['matched']['inputs'] as $input) {
                if (isset($input['name'])) {
                    $input_names[] = $input['name'];
                }
            }
        }
        $input_names_str = implode(', ', $input_names);

        try {
            $stmt->execute([
                ':external_id' => $external_id,
                ':published_date' => $published_date,
                ':source_id' => $source_id,
                ':social_network' => $social_network,
                ':country_code' => $country_code,
                ':country_name' => $country_name,
                ':author_name' => $author_name,
                ':content_image' => $content_image,
                ':content_text' => $content_text,
                ':url_destino' => $url_destino,
                ':input_names' => $input_names_str
            ]);
            $updatedCount++;
        } catch (PDOException $e) {
            error_log("Error al actualizar registro {$external_id}: " . $e->getMessage());
            continue;
        }
    }

    echo json_encode([
        'success' => true,
        'message' => "Se actualizaron {$updatedCount} registros correctamente."
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 