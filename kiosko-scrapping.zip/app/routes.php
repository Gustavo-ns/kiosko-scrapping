<?php

$router->get('/', 'HomeController@index');
$router->get('/scrape', 'ScraperController@scrape'); 